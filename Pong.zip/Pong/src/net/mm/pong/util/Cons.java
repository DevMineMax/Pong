package net.mm.pong.util;

public class Cons {
    public static final int SCREEN_WIDTH = 1020;
    public static final int SCREEN_HEIGHT = 720;
    public static final String SCREEN_TITLE = "Pong by MM";

}
