package net.mm.pong.game;

public class Vector2 {
    float x, y;
    public Vector2(float x, float y){
        this.x = x;
        this.y = y;
    }
}
